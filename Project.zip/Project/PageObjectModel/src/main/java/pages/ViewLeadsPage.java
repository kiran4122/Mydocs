package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class ViewLeadsPage extends ProjectSpecificMethods{
	
	public ViewLeadsPage (ChromeDriver driver) {
		this.driver=driver;
	}
	
	public ViewLeadsPage getPagetitle() {
		System.out.println("View leads page");
		return this;
	}
	
	

	public ViewLeadsPage editFirstLead() {
		driver.findElement(By.linkText("Edit")).click();
		return this;
	}


	public ViewLeadsPage updateFirstLead() {
		driver.findElement(By.id("updateLeadForm_companyName")).sendKeys("TCS");
		return this;
	}

	public ViewLeadsPage submitEditLead() {
		driver.findElement(By.name("submitButton")).click();
		return this;
		
	}


}
