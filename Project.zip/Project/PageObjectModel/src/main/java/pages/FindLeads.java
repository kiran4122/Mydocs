package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class FindLeads extends ProjectSpecificMethods{
	
	public FindLeads (ChromeDriver driver) {
		this.driver=driver;
	}
	

public FindLeads clickPhone() {
		
	driver.findElement(By.xpath("//span[text()='Phone']")).click();
	return this;
}

public FindLeads enterPhoneNumber() {
	driver.findElement(By.xpath("//input[@name='phoneNumber']")).sendKeys("99");
	return this;
}

public FindLeads clickFindLeads() throws InterruptedException {
	driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
	Thread.sleep(2000);
	return this;
}

public ViewLeadsPage selectFirstlead() {
	driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).click();
	return new ViewLeadsPage(driver);
}
}
