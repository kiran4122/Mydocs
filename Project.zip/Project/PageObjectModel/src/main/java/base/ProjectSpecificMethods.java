package base;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;





public class ProjectSpecificMethods {
	
	public ChromeDriver driver;
	 public String filename;
	 public Properties prop;
	@Parameters({"url"})	
	 @BeforeMethod
	 
	
		
		public void preCondition(String url) throws IOException 
		{
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.get(url);
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
			
			FileInputStream fis = new FileInputStream("src/main/resources/ConfigEnglish.properties");
			prop =new Properties();
			prop.load(fis);
			

		}

		
	
		@AfterMethod
		public void postCondition() {
			
			driver.close();
			
		}
		
		@DataProvider // (name="supplyData")
		public String[][] sendData() throws IOException {
			utils.ReadExcel exceldata = new utils.ReadExcel();
			String[][] data = exceldata.readData(filename);
			return data;
		}
	
	}


