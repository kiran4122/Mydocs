package testcase;

import java.io.IOException;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;




public class CreateLead extends ProjectSpecificMethods {
	
	@BeforeTest
	public void setValues() {
		filename="CreateLeadData";
		
	}
	
	@Test(dataProvider="sendData")
public void createLead(String cname,String fname,String lname,String phno) {
		
		LoginPage lp = new  LoginPage(driver);
		
		lp.enterUsername().enterPassword().clickLogin().clickCRMSFA().clickLeads().clickCreateLead().enterCompanyName(cname)
		.enterFirstName(fname).enterLastName(lname).enterPrimayphoneNo(phno).clickCreateLeadButton().getPagetitle();
		
		
		
	
		
	}

}
