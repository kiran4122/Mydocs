package testcase;

import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class EditLead extends ProjectSpecificMethods{
	@Test
	public void editingLead() throws InterruptedException {
			
			LoginPage lp = new  LoginPage(driver);
			
			lp.enterUsername().enterPassword().clickLogin().clickCRMSFA().
			clickLeads().findLeads().clickPhone().enterPhoneNumber().
			clickFindLeads().selectFirstlead().editFirstLead().
			updateFirstLead().submitEditLead();
			
		}

	}


