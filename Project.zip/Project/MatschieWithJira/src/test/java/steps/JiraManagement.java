package steps;

import java.io.File;
import static org.hamcrest.Matchers.containsInAnyOrder;
import org.hamcrest.Matchers;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class JiraManagement extends Common {
	
	public static Response response;
	public static RequestSpecification inputRequest;
	
	
	
	@When("Create the issue with file {string}")
	public void createIssueFile(String fileName) {
		File file = new File("./src/test/resources/"+fileName);
		inputRequest=RestAssured.given().contentType("application/json").when().body(file);
		response=inputRequest.post("issue");
		bug_id = response.jsonPath().getString("id");
	}
		
	@When("Update the issue with file {string}")
	public void updateIssueFile(String fileName) {
		File file = new File("./src/test/resources/"+fileName);
		inputRequest=RestAssured.given().contentType("application/json").when().body(file);
		response=inputRequest.put("issue/"+bug_id);
	}
	
	@When("Delete Issue")
	public void deleteIssue() {
		
		response=RestAssured.delete("issue/"+bug_id);
	}
		@Then("validate response code as {int}")
		public void validateResponseCode(int statuCode) {
			response.then().assertThat().statusCode(Matchers.equalTo(statuCode));
		}

}
