package steps;

import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

public class Common {
	public static RequestSpecification input;
	public static Response response;
	public static String bug_id;
}
