package services;

import java.io.File;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBodyExtractionOptions;
import io.restassured.response.ValidatableResponse;

import static org.hamcrest.Matchers.*;

public class JiraTests extends BaseRequest{
	
	public String bug_id;

	@Test
	public void createIssue(){
		 Response response = RestAssured.given()	.contentType("application/json").when()	
		.body(new File("./data/CreateIssue.json"))
			.post("issue");
		 bug_id = response.jsonPath().getString("id");
		 response.then().assertThat().statusCode(Matchers.equalTo(201));
		 response.prettyPrint();
		
	}
	
	@Test
	public void updateIssue() {
		
		Response response =	RestAssured.given()	.contentType("application/json").when()	
		.body(new File("./data/UpdateIssue.json"))
		.put("issue/"+bug_id);
	response.prettyPrint();
	response.then().assertThat().statusCode(Matchers.equalTo(204));
	}
	
     
@Test
	public void deleteIssue() {
	Response response = RestAssured.when()
		.delete("issue/"+bug_id);
	response.prettyPrint();
	response.then().assertThat().statusCode(Matchers.equalTo(204));

	}
	
	
	
}
