package base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class LearnCheckedException {

	
	public static void add(int x,int y) throws InterruptedException {
		
		if(x>y) {
			System.out.println(x+y);
			Thread.sleep(1000);
		}else {
			throw new RuntimeException("Check your inputs");
		}
	}
	
	
	public static void main(String[] args) throws FileNotFoundException, InterruptedException {

		//FileInputStream f=new FileInputStream("");
		add(2,8);
	}

}
