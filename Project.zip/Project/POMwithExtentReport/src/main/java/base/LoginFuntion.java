package base;

public class LoginFuntion extends LearnEncapsulation{

	public static void main(String[] args) {
		LoginFuntion lf=new LoginFuntion();
		System.out.println(lf.getPwd());
		lf.setPwd(123);
		System.out.println(lf.getPwd());

	}

}
