package testcase;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class Loginfuntionality extends ProjectSpecificMethod{
//execution 
	/*
	 * @BeforeSuite-->starts the report
	 * 
	 * @BeforeTest-->set the datafilename /test details
	 * 
	 * @BeforeClass->testdetails attaching to report
	 * 
	 * @DataProvider
	 * 
	 * @BeforeMethod -->projectSpecificmethod
	 * 
	 * @Test Loginpage -->reportstep-->takesnap
	 * 
	 * @AfterMethod-->closesthe browser
	 * 
	 * @AfterSuite -->close the report
	 * 
	 */
	 
	

	@BeforeTest
	public void setValues() {
	
		testName="Login functionality";
		testDesc="Login with positive credentials";
		author="Prabha";
		category="Functional";
	}	
	
	@Test
	public void runLogin() throws IOException {
		
		LoginPage lp=new LoginPage();	//1234	
		lp.enterUsername().enterPassword().clickLogin();
		
		
	}
	//before suite -->collects based data testcase-->testdeatils-->BeforeMethod
}