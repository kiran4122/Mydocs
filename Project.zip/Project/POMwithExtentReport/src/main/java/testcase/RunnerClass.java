package testcase;

import org.testng.annotations.BeforeTest;

import base.ProjectSpecificMethod;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features="src/main/java/features/TC001_login.feature" ,glue="pages",monochrome=true,
dryRun=true)
public class RunnerClass extends ProjectSpecificMethod{
	

	@BeforeTest
	public void setValues() {
	
		testName="Login functionality in Cucumber";
		testDesc="Login with positive credentials";
		author="Prabha";
		category="Functional";
	}	
	

}
