package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class LoginPage extends ProjectSpecificMethod{
	
	/*
	 * public LoginPage(ChromeDriver driver) { this.driver=driver; }
	 */
	 
	
	@Given("Enter the username")
	public LoginPage enterUsername() throws IOException {
		try {
			getDriver().findElement(By.id("username")).sendKeys(prop.getProperty("username"));
			reportStep("pass","Entered the username successful");
		} catch (Exception e) {
			reportStep("fail", "Entered the username not successful");
		}	
		
		return this;
	}

	@Given("Enter the password")
	public LoginPage enterPassword() throws IOException {
		try {
			getDriver().findElement(By.id("password")).sendKeys(prop.getProperty("password"));
			reportStep("pass", "Entered the password successful");
		} catch (Exception e) {
			reportStep("fail", "Entered the password not successful");
		}
		return this;
	}

	@When("Click on Login button")
	public WelcomePage clickLogin() throws IOException {
		try {
			getDriver().findElement(By.className("decorativeSubmit")).click();
			reportStep("pass", "Login is clicked successful");
		} catch (Exception e) {
			reportStep("fail", "Login is not clicked successfully");
		}
		return new WelcomePage();
	}

}
//method chaining
//enterusername-->password-->login
//username -->password-->login-->crmsfa-->leads-->crealead->cname->fname->lname->create->viewlead
//username->password->login->logout