package home.assignment;

public class PrimeNumber1 {

	public static void main(String[] args) {

		int num = 20;
		boolean prime= true;
		
		for (int i=2;i<num;i++) {
			
			if (num%i==0) {
				
				prime =false;
				System.out.println("The number is not prime:"+num);
				break;
				
				
			}
		}
		System.out.println(prime);

	}

}
