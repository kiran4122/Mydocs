package home.assignment;

public class NegtiveToPositive {

	public static void main(String[] args) {
		
		int n = -40;
		int j;
		if(n<0) {
		j=-(n);
		System.out.println("The number "+n+" is converted to "+j);
		 
		}
		else {
			System.out.println("The entered number is positive");
		}
			}
		}
