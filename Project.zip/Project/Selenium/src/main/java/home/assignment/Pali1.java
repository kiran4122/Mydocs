package home.assignment;

public class Pali1 {

	public static void main(String[] args) {
		int r,temp,sum=0;
		int num = 121;
		
		temp = num;
		
		while (num>0) {
			r=num%10;
			sum = (sum*10)+r;
			num=num/10;
		}
			if (temp==sum) {
				System.out.println("the number is palindrome");
			}
			
			else {
				System.out.println("the number is not palindrome");
			}
			
		}

	}

