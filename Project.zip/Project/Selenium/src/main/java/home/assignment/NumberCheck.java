package home.assignment;

public class NumberCheck {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int i = -9;
		
		if (i>0) {
			
			System.out.println("The entered number is positive");
		}
		else if (i<0){
			
			System.out.println("The entered number is negative");
			
		}
		
		else if (i==0){
			
			System.out.println("The number is neither positive nor negative");
			
		}
		}

	

}
