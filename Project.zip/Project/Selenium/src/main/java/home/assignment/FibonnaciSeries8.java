package home.assignment;

public class FibonnaciSeries8 {

	public static void main(String[] args) {
		
		int num = 20;
		int f=0,s=1,t;
		
		System.out.println(f);
		System.out.println(s);
		
		for (int i=3;i<=num;i++) {
			
			t=f+s;
			System.out.println(t);
			
			f=s;
			s=t;
		}

	}

}
