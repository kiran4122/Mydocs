package home.assignment;

public class Browser {
	
	public static void main(String[] args) {
		
		System.out.println("This is my browser");
	}

}
