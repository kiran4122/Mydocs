package home.assignment;

public class SumofNumbers {

	public static void main(String[] args) {
	
		int x = 5;
		System.out.println(x++ + ++x);
	/*	int sum = 0;
		
		while (n>0) {
			
			int temp = n%10;
			sum = sum +temp;
			
			n=n/10;
			
			
		}
		
		System.out.println("the sum is "+sum);
	}
*/
}
}
