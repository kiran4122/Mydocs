package week6.day2;

import org.openqa.selenium.By;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class RedHat extends BaseClass {
	
	@BeforeTest
	public void setValues() {
		filename="RedHatData";
		
	}
	
	@Test(dataProvider = "sendData")
	public void registerAccount(String username, String password, String email, String phno) {
		System.out.println(Thread.currentThread().getId());
		
driver.findElement(By.id("username")).sendKeys(username);
driver.findElement(By.id("password")).sendKeys(password);
driver.findElement(By.id("email")).sendKeys(email);
driver.findElement(By.id("user.attributes.phoneNumber")).sendKeys(phno);
driver.findElement(By.id("regform-submit")).click();
	}

}


