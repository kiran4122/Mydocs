package week6.day2;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import io.github.sukgu.Shadow;

public class ServiceNowDelete extends ServiceBaseClass {

	@Test
	public void deleteService() throws InterruptedException {
		
		
		Shadow dom = new Shadow(driver);
		dom.setImplicitWait(10);
		dom.findElementByXPath("//div[text()='All']").click();
		dom.findElementByXPath("//span[contains(text(),'Incidents')]").click();
		 WebElement eleFrame = dom.findElementByXPath(("//iframe[@title='Main Content']"));
		 driver.switchTo().frame(eleFrame);
		 String attribute = driver.findElement(By.xpath("(//td/a[@class='linked formlink'])[2]")).getText();
		 System.out.println(attribute);
		 driver.findElement(By.xpath("(//td/a[@class='linked formlink'])[2]")).click();
		 driver.findElement(By.xpath("//button[text()='Delete']")).click();
		 driver.findElement(By.xpath("(//button[text()='Delete'])[3]")).click();
		 Thread.sleep(5000);
		 
		 WebElement findElement2 = driver.findElement(By.xpath("(//input[@class='form-control'])[1]"));	
		 findElement2.sendKeys(attribute,Keys.ENTER);
	String text = driver.findElement(By.xpath("//div/div[contains(text(),'No records to display')]")).getText();
	System.out.println(text);
	String expected = "No records to display";
	if(expected.equalsIgnoreCase(text)) {
		System.out.println("Deleted successfully");
	}
	else {
		System.out.println("Not deleted");
	}
		 
		 
	}

}
