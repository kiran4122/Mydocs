package week6.day2;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

public class BaseClass {
	
	public ChromeDriver driver;

	public String filename;

	@Parameters({ "url" })
	@BeforeMethod
	public void browserSetUp( String url) {
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(url);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.findElement(By.xpath("//button[contains(text(),'Register')]")).click();
		String text = driver.findElement(By.xpath("//h1[contains(text(),'Register')]")).getText();
		System.out.println(text);
		if(text.equals("Register for a Red Hat account")) {
			System.out.println("Registration page got loaded");
		}
		else {
			System.out.println("Registration page not loaded");
		}
	}

	@AfterMethod
	public void tearDown() {
		driver.quit();
	}

	@DataProvider // (name="supplyData")
	public String[][] sendData() throws IOException {
		ReadExcel exceldata = new ReadExcel();
		String[][] data = exceldata.readData(filename);
		return data;
	}

}


