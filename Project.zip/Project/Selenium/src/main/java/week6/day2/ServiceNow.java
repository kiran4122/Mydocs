package week6.day2;


import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.sukgu.Shadow;

public class ServiceNow extends ServiceBaseClass {
	
	@BeforeTest
	public void setValues() {
		filename="ServiceNow";
		
	}
	

	@Test(dataProvider = "sendData")
	public void createIncident(String cname) { 
	
		Shadow dom = new Shadow(driver);
		dom.setImplicitWait(10);
		dom.findElementByXPath("//div[text()='All']").click();
		dom.findElementByXPath("//span[contains(text(),'Incidents')]").click();
		 WebElement eleFrame = dom.findElementByXPath(("//iframe[@title='Main Content']"));
		 driver.switchTo().frame(eleFrame);
		 driver.findElement(By.xpath("//button[text()='New']")).click();
		 String text3 = driver.findElement(By.xpath("//div/input[@id='incident.number']")).getAttribute("value");
		 System.out.println("First page id : "+text3);
	 driver.findElement(By.xpath("//input[@id='incident.short_description']")).sendKeys(cname);
	
	 driver.findElement(By.xpath("//button[text()='Submit']")).click();
	 
	 String text4 = driver.findElement(By.xpath("(//td/a[@class='linked formlink'])[6]")).getText();
	 System.out.println("second page id : "+text4);
	 
	 if(text3.equals(text4)) {
		 System.out.println("Incident created");
	 }
	 else {
		System.out.println("Incident not created");
	}
	 


	 
	}
}
