package week6.day2;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import io.github.sukgu.Shadow;

public class ServiceNowEdit extends ServiceBaseClass{

	@Test
	public  void editService() {
		Shadow dom = new Shadow(driver);
		dom.setImplicitWait(10);
		dom.findElementByXPath("//div[text()='All']").click();
		dom.findElementByXPath("//span[contains(text(),'Incidents')]").click();
		 WebElement eleFrame = dom.findElementByXPath(("//iframe[@title='Main Content']"));
		 driver.switchTo().frame(eleFrame);
		 driver.findElement(By.xpath("(//td/a[@class='linked formlink'])[2]")).click();
		 WebElement findElement = driver.findElement(By.xpath("//select[@id='incident.urgency']"));
		 
		 Select dropdown = new Select(findElement);
		 
		 dropdown.selectByValue("1");
		 
	 WebElement findElement1 = driver.findElement(By.xpath("//select[@id='incident.state']"));
		 
		 Select dropdown1 = new Select(findElement1);
		 
		 dropdown1.selectByValue("2");
		 
		 driver.findElement(By.xpath("//button[text()='Update']")).click();
		 String text = driver.findElement(By.xpath("(//td/a[@class='linked formlink'])[2]")).getText();
		 System.out.println(text);
		 
		 WebElement findElement2 = driver.findElement(By.xpath("(//input[@class='form-control'])[1]"));	
		 findElement2.sendKeys(text);
		 findElement2.click();
		 
		 driver.findElement(By.xpath("(//td/a[@class='linked formlink'])[2]")).click();
		 String expectedValue="In Progress";
		 
	 String text2 = driver.findElement(By.xpath("//span/span[text()='In Progress']")).getText();
		 System.out.println(text2);
		 if(expectedValue.equals(text2)) {
			 System.out.println("Incident updated successfully");
		 }
		 else {
			System.out.println("Incident not updated");
		}
		 
	}

}
