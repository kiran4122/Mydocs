package week2.day1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SampleRun {

	public static void main(String[] args) {
		
		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.amazon.in/");
		
		WebElement bestseller = driver.findElement(By.partialLinkText("Best Sellers"));
		System.out.println(bestseller.getText());
		driver.findElement(By.partialLinkText("Best Sellers")).click();
		driver.close();

	}

}
