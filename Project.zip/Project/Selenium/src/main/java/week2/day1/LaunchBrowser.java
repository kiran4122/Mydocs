package week2.day1;

import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.edge.EdgeDriver;

public class LaunchBrowser {

	public static void main(String[] args) {

		ChromeDriver driver = new ChromeDriver();
		//EdgeDriver driver1= new EdgeDriver();
		driver.manage().window().maximize();
		driver.get("http://leaftaps.com/opentaps/control/main");
		
		//driver1.manage().window().maximize();
	//	driver1.get("http://leaftaps.com/opentaps/control/main");
		driver.close();
	//	driver1.close();

	}

}
