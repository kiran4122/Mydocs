package week4.day2;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebTestLeaf {

	public static void main(String[] args) {
		ChromeDriver driver = new ChromeDriver();
		System.out.println(driver);
		driver.get("https://www.leafground.com/table.xhtml");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		WebElement table = driver.findElement(By.xpath("//div[@class='ui-datatable-scrollable-body']/table"));

			List<WebElement> row = table.findElements(By.tagName("tr"));
			System.out.println(row.size());
			
			List<WebElement> col = row.get(1).findElements(By.tagName("td"));
			System.out.println(col.size());
			
			// print one row
			for (int i = 1; i < col.size(); i++) {
				
				WebElement rowPrint = driver.findElement(By.xpath("//div[@class='ui-datatable-scrollable-body']/table/tbody/tr[2]/td[" + i + "]"));
				

				System.out.println(rowPrint.getText());
				
			}
			
			
			// print one column
			for (int i = 1; i < row.size(); i++) {
				
				WebElement colPrint = driver.findElement(By.xpath("//div[@class='ui-datatable-scrollable-body']/table/tbody/tr[" + i + "]/td[3]"));
				//WebElement colPrint = driver.findElement(By.xpath("//div[@class='ui-datatable-scrollable-body']/table/tbody/tr[" + i + "]/td[2]"));

				System.out.println(colPrint.getText());
				
			}
				
				for(int j = 1; j < row.size(); j++) {
					 for (int i = 1; i < col.size(); i++) {
						
						WebElement fullPrint = driver.findElement(By.xpath("//div[@class='ui-datatable-scrollable-body']/table/tbody/tr[" + j + "]/td["+ i +"]"));
						System.out.print(fullPrint.getText()+" ");
					}
					System.out.println();
				}
				
			}
	}


