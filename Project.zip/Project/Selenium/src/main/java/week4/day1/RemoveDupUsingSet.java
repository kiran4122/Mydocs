package week4.day1;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

public class RemoveDupUsingSet {
	
	public static void main(String[] args) {
		
		String sentence="google";
		
		char[] charArray = sentence.toCharArray();
		
		Set<Character> unique=new LinkedHashSet<Character>();
		for (int i = 0; i < charArray.length; i++) {
			unique.add(charArray[i]);
			
		}	
		
		for (Character name:unique) {
			System.out.print(name);
		}
	}

}
