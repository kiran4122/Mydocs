package week3.day1;

public class Edge extends Browser {

	
	public void takeSnap()
	{
		System.out.println("takeSnap");
	}

	public void clearCookies()
	{
		System.out.println("clearCookies");
	}

	
	public static void main(String[] args) {
		Edge new2= new Edge();
		new2.openURL();
	new2.closeBrowser();
	new2.navigateBack();
	
new2.takeSnap();
new2.clearCookies();

	}
}
