package week3.day1;

public class Execution {

	public static void main(String[] args) {
		
		Car c1 = new Car();
		
		c1.ApplyBrake();
	
		
	}

}
