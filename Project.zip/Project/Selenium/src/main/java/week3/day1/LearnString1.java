package week3.day1;

public class LearnString1 {

	public static void main(String[] args) {
		


		        String inputString = "Testleaf";
		        char[] charArray = inputString.toCharArray();
		        int len = charArray.length;
		        int count=0;
		        char tofind = 'e';
		        
		        for (int i=0;i<len;i++) {
		        	if (charArray[i]==tofind) {
		        		count++;
		        	}
		        	
		        }
System.out.println("charcter: " +tofind+ " repeated " +count+ " times");
		       
		        }
		   
}




