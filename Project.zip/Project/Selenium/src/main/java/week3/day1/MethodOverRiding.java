package week3.day1;

public class MethodOverRiding {
	
		
	public void ApplyBrake()
	{
		System.out.println("The Brake is applied: Normal Brake");
	}
	
	public static void main(String[] args) {
		

		MethodOverRiding mover = new MethodOverRiding();
		mover.ApplyBrake();
	}

	
	
	
}
