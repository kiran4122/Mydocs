package week3.day1;



public class Chrome extends Browser{
	
	public static void main(String[] args) {
		
		Chrome new1= new Chrome();
		new1.openURL();
	new1.closeBrowser();
	new1.navigateBack();
	
new1.openIncgnito();
new1.clearCache();
		
	}
		
	

	
	public void openIncgnito()
	{
		System.out.println("openincognito");
	}

	public void clearCache()
	{
		System.out.println("clearCache");
	}




}
	
	

