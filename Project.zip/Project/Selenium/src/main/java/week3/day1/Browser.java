package week3.day1;

public class Browser {
	
	String browserName = "opera";
	String browserVersion= "5.9";

	public void openURL() {
	
		System.out.println("openURL");
}
	
	public void closeBrowser() {
		
		System.out.println("closebrowser");
}
	public void navigateBack() {
		
		System.out.println("navigateBack");
}
}