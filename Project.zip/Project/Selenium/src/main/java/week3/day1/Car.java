package week3.day1;

public class Car extends MethodOverRiding{
	
	public void ApplyBrake()
	{
		System.out.println("The Brake is applied: ABS Brake");
		super.ApplyBrake();
	}
 public static void main(String[] args) {
	
	 Car ap = new Car();
	 
	 ap.ApplyBrake();
	 
}

}
