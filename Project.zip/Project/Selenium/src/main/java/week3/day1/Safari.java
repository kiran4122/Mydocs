package week3.day1;

public class Safari extends Browser {
	
	public static void main(String[] args) {
		Safari new1= new Safari();
		new1.openURL();
	new1.closeBrowser();
	new1.navigateBack();
	new1.readerMode();
	new1.fullScreenMode();

		
	}
	
	public void readerMode()
	{
		System.out.println("readerMode");
	}

	public void fullScreenMode()
	{
		System.out.println("fullScreenMode");
	}

}
