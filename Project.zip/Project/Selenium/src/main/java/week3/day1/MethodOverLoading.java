package week3.day1;

public class MethodOverLoading {
	
	
	
	public void reportStep(String msg, String status)
	{
		System.out.println("Message is :" +msg+" Status is :" +status);
	}


	public void reportStep(String msg, String status, Boolean Snap)
	{
		System.out.println("Message is :" +msg+" Status is :"+status+" Boolean value is : " +Snap);
	}
	public static void main(String[] args) {
		
		MethodOverLoading rp = new MethodOverLoading();
		rp.reportStep("test", "active");
		rp.reportStep("rp", "inactive", false);
		


	}

}
