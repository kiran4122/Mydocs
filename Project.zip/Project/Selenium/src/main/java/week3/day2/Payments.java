package week3.day2;

public interface Payments {
	
	public void cashOnDelivery();
	public void upiPayments();
	public void internetBanking();
	public void cardPayments();
}
