package week3.day2;

public class ExecutionCl1 extends Button{

	public static void main(String[] args) {
		
		ExecutionCl1 c1 = new ExecutionCl1();
		c1.click();
		c1.setText("testqw");
		c1.submit();
	
		}

}
