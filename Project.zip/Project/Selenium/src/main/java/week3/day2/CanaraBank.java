package week3.day2;

public abstract class CanaraBank implements Payments {
	
	//unimplemented method (Abstract)
	public abstract void recordPaymentDetails();

	
	//implementing method
	
public void ChequeBook () {
	
	
	System.out.println("test1");
}

}