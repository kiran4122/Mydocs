package week3.day2;

public abstract class MySqlConnection implements DatabaseCollection {
	
	public abstract void executeQuery();

}
