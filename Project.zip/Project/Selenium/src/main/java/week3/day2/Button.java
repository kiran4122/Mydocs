package week3.day2;

public class Button extends WebElement{
	
	public static void main(String[] args) {
		
		Button ele = new Button();
		ele.click();
		ele.setText("test1");
		ele.submit();
	}
	
	public void submit() {
		System.out.println("cute");
	}

}
