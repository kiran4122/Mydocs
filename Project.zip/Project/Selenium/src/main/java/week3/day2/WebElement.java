package week3.day2;

public class WebElement {
	
	public void click() {
		System.out.println("Click");
	}
	
	
	public void setText(String text) {
		System.out.println(text);
	}
	
	
	

}
