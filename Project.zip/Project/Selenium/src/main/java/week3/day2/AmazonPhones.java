package week3.day2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AmazonPhones {

	public static void main(String[] args) {
		ChromeDriver driver = new ChromeDriver();
        driver.get("https://www.amazon.in/");
        driver.manage().window().maximize();
     driver.findElement(By.xpath("//input[@id='twotabsearchtextbox']")).sendKeys("Phones");
     driver.findElement(By.xpath("//input[@type='submit']")).click();
     List<WebElement> phone = driver.findElements(By.xpath("//span[@class='a-price-whole']"));
     
     List<Integer> pdtPrices = new ArrayList<Integer>();
     for (int i = 0; i < phone.size(); i++) {
    //	System.out.println(phone.get(i).getText());
    	
		String text = phone.get(i).getText();
		
		String replaceAll = text.replaceAll(",","");
		int number = Integer.parseInt(replaceAll);
		//List<Integer> pdtPrices = new ArrayList<Integer>();// empty list

		pdtPrices.add(number);
	}

	System.out.println(pdtPrices);

	Collections.sort(pdtPrices);

	System.out.println(pdtPrices);

	// to min value
	Integer min = Collections.min(pdtPrices);
	System.out.println(min);

}
	
		
	}


