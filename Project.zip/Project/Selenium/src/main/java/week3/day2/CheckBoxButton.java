package week3.day2;

public class CheckBoxButton extends Button{
	
	public void clickCheckButton() {
		System.out.println("Click Check Button");
	}
public static void main(String[] args) {
	
	CheckBoxButton box = new CheckBoxButton();
	box.click();
	box.clickCheckButton();
	box.setText("new");
	box.submit();
}
}


