package week3.day2;

public class Amazon extends CanaraBank implements Payments {
	

	public void cashOnDelivery() {
		
		
	}
	public void cardPayments() {
		
	}
	public void upiPayments() {
		
		
	}

	public void internetBanking() {
		
		
	}
	
	public void recordPaymentDetails() {
		
		
	}

	

	public static void main(String[] args) {
	
Amazon a = new Amazon();
a.cardPayments();
a.cashOnDelivery();
a.internetBanking();
a.recordPaymentDetails();
a.upiPayments();
a.ChequeBook();
	}
	
}
