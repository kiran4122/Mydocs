package week1.day1;

public class Welcome {
	
	//type main-> Ctrl  space
	

	public static void main(String[] args) {
		
		//type syso ctrl space
		
		System.out.println("Welcome to TestLeaf");
		
	}
	
	
}
