package week1.day1;

public class Report {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	
		Student stu1 = new Student();
 System.out.println("Marks Scored :"+stu1.markScored); 
 System.out.println("CGPA is :"+stu1.cgpa);
 System.out.println("College Name:"+stu1.collegeName);
 System.out.println("Roll Number is :"+stu1.rollNo);
 System.out.println("Student Name :"+stu1.studentName);
 
		

		
	}

}
