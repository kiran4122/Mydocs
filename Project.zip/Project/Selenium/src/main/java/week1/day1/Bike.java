package week1.day1;

public class Bike {
	
	public static void main(String[] args) {
		
		Car spec = new Car();
		spec.applyBreak();
		spec.soundHorn();
		
		Bike spec1 = new Bike();
		spec.applyBreak();
		spec.soundHorn();
		
	}
	
	

}
