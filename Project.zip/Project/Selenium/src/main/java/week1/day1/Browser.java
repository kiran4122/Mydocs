package week1.day1;

public class Browser {
	
	public static void main(String[] args) {
		
		Chrome call = new Chrome ();
		call.getName();
		call.printName();
		
	}
	
	

}
