package week1.day1;

public class Chrome {
	
	public void getName ()
	{
		System.out.println("This is google chrome");
	}
	
	public void printName ()
	{
		System.out.println("This is chrome driver");
	}

}
