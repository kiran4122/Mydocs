package week1.day1;

public class Student {
	


		String studentName = "Kiran" ;
		long rollNo = 343454l ;
		String collegeName = "Anna Univ"  ;
		double markScored = 234.3;
		float cgpa = 8.9f ;
	
}
