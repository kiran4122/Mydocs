package week1.day1;

public class FireFox {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		float browserVersion = 100.2f;
		String browserName = "firefox";
		boolean isVisible = true;
		int releaseYear = 1998;
		char browserLogo = 'l';
		
		System.out.println("Browser version is :" +browserVersion);
		System.out.println("Browser name is :"+browserName);
		System.out.println("Browser is visible :"+isVisible);
		System.out.println("Browser release year :"+releaseYear);
		System.out.println("Browser logo is :"+browserLogo);

	}

}
