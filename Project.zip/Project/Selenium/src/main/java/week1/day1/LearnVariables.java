package week1.day1;

public class LearnVariables {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		char name = 'N';
		String fullName = "Kiran Thilak Navarathinam";
		int age = 33;
		String dateofBirth = "4th Dec 1989";
		String employedCompany = "Infosys";
		float height = 5.9f;
		long salary = 34443323l;
		double loanAccnt = 2347238.492349832;
		boolean haveCar = true;
		
		System.out.println(fullName+"."+name);
		System.out.println("My dob is :" + age);
		System.out.println(fullName+"."+height);
		System.out.println(dateofBirth);
		
	}

}
