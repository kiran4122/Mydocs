package week1.day2;

public class Edgebrowser {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Browser obj1 = new Browser();
		obj1.launchBrowser("edge");
		obj1.loadUrl();
	}

}
