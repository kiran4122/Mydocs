package week1.day2;

public class Evennum {

	public static void main(String[] args) {
		
		int n = 100;
		
		for (int i = 1;i<=n;i++) {
			
			if (i%2==0) {
				
				System.out.println("the number is even "+ i);
			}
				
				
			
			}
		}

	}


