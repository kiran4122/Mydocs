package week1.day2;

public class Ifelsestatement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int num=11;
		if (num>10) {
			System.out.println("The number is positive");
			
		}
		else if (num >23){
			System.out.println("the number is negative");
		} 
		
		else if (num>39) {
			System.out.println("the number is not entered");
		}
		else {
			System.out.println("the number does not exist");
		}
	}

}
