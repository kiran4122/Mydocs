package week1.day2;

public class Temp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str = "word";
		System.out.println(str);
		
		
	}

}
