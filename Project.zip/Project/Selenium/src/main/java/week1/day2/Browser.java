package week1.day2;

public class Browser {
	
	public String launchBrowser (String browserName) {
		System.out.println("Browser launched succsessfully:"+browserName);
		return browserName;
	}
	
	public void loadUrl() {
		System.out.println("Application url loaded successfully: https://platform.testleaf.com/");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Browser call = new Browser();
		call.launchBrowser("chrome");
		call.loadUrl();

	}

}
