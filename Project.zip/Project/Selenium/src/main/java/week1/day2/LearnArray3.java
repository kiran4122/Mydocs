package week1.day2;

import java.util.Arrays;

public class LearnArray3 {

	public static void main(String[] args) {
		
		int [] numbers = {32,56,15,15,23,32};
		
		//int size = numbers.length;
		
		Arrays.sort(numbers);
		
		for (int i =0; i<numbers.length-1; i++) {
			
		if (numbers [i] ==numbers [i+1]){

			System.out.println(numbers[i]);
		}
		}
	}

}
