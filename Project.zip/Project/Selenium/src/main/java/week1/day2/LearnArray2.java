package week1.day2;

public class LearnArray2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String [] week= {"week1","week2","week3"};
		String [] day = {"day1","day2","day3"};
		
		for(int i=0;i<week.length;i++) {
			System.out.println(week[i]);
			
			for (int j=0;j<day.length;j++) {
				
				System.out.println(day[j]);
			}
			}
		}
			

	}


