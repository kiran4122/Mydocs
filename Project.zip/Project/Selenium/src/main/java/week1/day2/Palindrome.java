package week1.day2;

		
		public class Palindrome {

		    public static boolean isPalindrome(String str) {
		        // Remove non-alphanumeric characters and convert to lowercase
		        String cleanStr = str.replaceAll("[^a-zA-Z0-9]", "").toLowerCase();

		        // Compare the original and reversed strings
		        return cleanStr.equals(new StringBuilder(cleanStr).reverse().toString());
		    }

		    public static void main(String[] args) {
		        // Example usage
		        String palindromeString = "A man, a plan, a canal, Panama!";
		        boolean isPalindrome = isPalindrome(palindromeString);

		        if (isPalindrome) {
		            System.out.println("'" + palindromeString + "' is a palindrome.");
		        } else {
		            System.out.println("'" + palindromeString + "' is not a palindrome.");
		        }
		    }
		


	}


