package week1.day2;

import java.util.Arrays;

public class ArraysLearn {
	
	public static void main(String[] args) {
	
	int [] scores = {53,34,67,90,23};
		
		int size = scores.length;
		
		System.out.println("the length is:"+size);
		
		System.out.println(scores[2]);
		
		for (int i = 0; i<size; i++) {
			
			System.out.println(scores[i]);
			
		}
		
		System.out.println("sort");
		
		Arrays.sort(scores);
for (int i = 0; i<size; i++) {
			
			System.out.println(scores[i]);
			//System.out.println(scores[0]);
			//System.out.println(scores[size-1]);
}

System.out.println("reverse");

for (int i=size-1;i>=0;i--)
{
	System.out.println(scores[i]);
}
}
		
	

}
