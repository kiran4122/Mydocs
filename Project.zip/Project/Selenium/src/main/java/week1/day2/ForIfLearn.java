package week1.day2;

public class ForIfLearn {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	
		
		for (int i = 1;i<=20;i++)
		
		if (i%2==0) {
			
			
			System.out.println("The number is even :"+ i);
			
			
		}

	}

}
