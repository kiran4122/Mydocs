package week1.day2;

public class AddNumbers {
	
	public void Addnumbers1 (int x,int y) {
		
		System.out.println(x+y);
	}
	
			
			public void sub (int x,int y) {
				
				System.out.println(x-y);
			}
			
	public void multiply (int x,int y) {
				
				System.out.println(x*y);
			}
	public void division (int x,int y) {
		
		System.out.println(x/y);
	}
	public void mod (int x,int y) {
		
		System.out.println(x%y);
	}
			
			
	
	public static void main(String[] args) {
		
		AddNumbers num = new AddNumbers();
		num.Addnumbers1(20, 30);
		num.sub(50, 30);
		num.multiply(2,3);
		num.division(10, 2);
		num.mod(10, 3);
		
		
	}

}
