package week1.day2;

import java.util.Arrays;


public class ArrayMissing {
	
	public static void main(String[] args) {
		
		int [] scores = {1,4,3,2,8,6,7};
		 
		Arrays.sort(scores);
		
	for (int i = 0; i < scores.length; i++) {
		if (scores[i]!=i+1) {
			System.out.println(i+1);
			break;
		}
		
	}
		
	}

}

