package week1.day2;

public class Multiply {

	public static void main(String[] args) {
		
	int n = 2;
		
		for (int i = 1; i<=15 ; i++) {
			System.out.println(n*i);
		}
		
		// TODO Auto-generated method stub

	}

}
