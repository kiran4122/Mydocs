package stepdef;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.cucumber.java.en.And;
import io.cucumber.java.en.But;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CreateAccount extends BaseClass{
	

	/*
	 * public ChromeDriver driver;
	 * 
	 * @Given("Launch the browser") public void launchBrowser() { driver = new
	 * ChromeDriver();
	 * 
	 * }
	 * 
	 * @And("Load the url")
	 * 
	 * public void loadUrl() { driver.manage().window().maximize();
	 * driver.get("http://leaftaps.com/opentaps/");
	 * driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5)); }
	 */
	 
	@Given("Enter the username as {string}")
	public void enterUsername(String uname) {
		driver.findElement(By.id("username")).sendKeys(uname);
	}

	@Given("Enter the password as {string}")
	public void enterPassword(String pwd) {
		driver.findElement(By.id("password")).sendKeys(pwd);
	}

	@When("Click on Login button")
	public void clickLogin() {
		driver.findElement(By.className("decorativeSubmit")).click();
	}

	@Then("Welcome page is displayed")
	public void VerifyWelcomePage() {
		System.out.println(driver.getTitle());
	}


	@When("Click on CRMSFA link")
	public void click_on_crmsfa_link() {
		WebElement crmsfa = driver.findElement(By.linkText("CRM/SFA"));
		System.out.println(crmsfa.getText());
		driver.findElement(By.linkText("CRM/SFA")).click();
		String title = driver.getTitle();
		System.out.println(title);
	  
	}
	
	@When("Click on Create Account link")
	public void click_on_create_account_link() {
		driver.findElement(By.xpath("//a[contains(text(),'Create Account')]")).click();
	    
	}
	@When("Enter the Accountname as {string}")
	public void enter_the_accountname_as(String accname) {
		driver.findElement(By.id("accountName")).sendKeys(accname);
	}
	@When("Enter the Description as {string}")
	public void enter_the_description_as(String descname) {
		driver.findElement(By.xpath("//textarea[@name='description']")).sendKeys(descname);
	    
	}
	@When("Enter the Groupname as {string}")
	public void enter_the_groupname_as(String grpname) {
		driver.findElement(By.xpath("//input[@id='groupNameLocal']")).sendKeys(grpname);
	    
	}
	@When("Enter the Officialsitename as {string}")
	public void enter_the_officialsitename_as(String offlname) {
		driver.findElement(By.xpath("//input[@id='officeSiteName']")).sendKeys(offlname);
	   
	}
	@When("Enter the Annualrevenue as {string}")
	public void enter_the_annualrevenue_as(String rev) {
		driver.findElement(By.xpath("(//input[@class='inputBox'])[5]")).sendKeys(rev);
	    
	}
	@When("Enter the Industry")
	public void enter_the_industry() {
		WebElement dropdown = driver.findElement(By.xpath("//select[@name='industryEnumId']"));
		Select dd = new Select(dropdown);
		dd.selectByVisibleText("Computer Software");
	    
	}
	@When("Click on Create button")
	public void click_on_create_button() {
		driver.findElement(By.xpath("//input[@class='smallSubmit']")).click();
	    
	}
	@Then("AccountDeatils page is displayed")
	public void account_deatils_page_is_displayed() {
		String title2 = driver.getTitle();
		System.out.println(title2);

	    
	}

}



