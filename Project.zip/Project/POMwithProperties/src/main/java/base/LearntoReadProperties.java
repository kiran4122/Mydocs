package base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class LearntoReadProperties {

	public static void main(String[] args) throws IOException {
		
		
		//1.set the filepath
		
		FileInputStream fis=new FileInputStream("src/main/resources/ConfigFrench.properties");
		
		//step:2 use Properties class to read the values from the file
		Properties prop=new Properties();
		prop.load(fis);
		
		System.out.println(prop.getProperty("username"));
		System.out.println(prop.getProperty("password"));

		

	}

}
