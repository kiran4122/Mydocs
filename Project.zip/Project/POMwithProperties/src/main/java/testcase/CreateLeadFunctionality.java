package testcase;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;
import pages.WelcomePage;

public class CreateLeadFunctionality extends ProjectSpecificMethod{

	
	@BeforeClass
	public void setValues() {
		filename="CreateLeadData";
		
	}
		
	@Test(dataProvider="sendData")
	public void runCreate(String cname,String fname,String lname,String phno) {
		
		LoginPage lp=new LoginPage(driver);
		
		lp.enterUsername().enterPassword().clickLogin().clickCRMSFA().clickLeads()
		.clickCreatelead().enterCompanyName(cname).enterFirstName(fname).enterLastName(lname).enterPhno(phno).clickCreate()
		.verifyPagetitle();
		
		
		
		
	}
	
	
	
}
